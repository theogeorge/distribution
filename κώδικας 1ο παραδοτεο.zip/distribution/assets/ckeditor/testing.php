<script src="plugins/ckeditor_wiris/integration/WIRISplugins.js?viewer=image"></script>
<?php 
    echo $_POST['math'];
    // echo base64_decode($_POST['math']);
?>