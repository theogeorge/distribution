

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `role_id_2` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO admin VALUES
("1","Sabeeh","Murtaza","sabeehmurtaza9","sabeehmurtaza9@gmail.com","505dd68d1d5f41f8148eebd83b29d58f","923159111969","1","0"),
("2","Baqir","Bajwa","baqir","baqirbajwa@yahoo.com","500f98179cacb15af39972bdd701646a","0000000000","2","0"),
("3","Atif","Razzaq","atif","atifrazzaqdashti@gmail.com","c6f057b86584942e415435ffb1fa93d4","3027566364","2","0");--


--

CREATE TABLE `api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--


--

CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(300) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `b_head` varchar(100) NOT NULL,
  `b_h_contact` varchar(20) NOT NULL,
  `c_person` varchar(200) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
INSERT INTO branch VALUES
("1","Branch 1","36,37, zainab tower, link road lahore ","000000000000","Branch Head","000000000000","Baqir Bajwa","1"),
("2","abcdefjighasdasdasdasd","testing 123","-30","1212","123123","baqir","1"),
("3","hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh","hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh","-2222","hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh","hhhhhhhhhhhhhhhhhhhh","hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh","0"),
("4","%%3..>,","&&**","123123","&&**^ %$%!@#","213123123","55%%^^&*","1"),
("5","1","1","1","1","1","1","0"),
("6","asd","1","1","asd","1","asdad","0");--


--

CREATE TABLE `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` text NOT NULL,
  `district_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `province_id` int(11) NOT NULL,
  `is_delete` int(11) DEFAULT '0',
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
INSERT INTO city VALUES
("1","Riwind","1","0","0","0"),
("2","shadra","1","0","0","0"),
("3","sadiq abad","2","0","0","0"),
("4","Rahim yar khan","2","0","0","0");--


--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `class_name` text NOT NULL,
  `description` text NOT NULL,
  `tution_fee` bigint(20) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
INSERT INTO class VALUES
("1","2","10th","asdfg","1200","0"),
("2","2","10th","dfghjk","1200","0"),
("3","2","10th","","1200","1"),
("4","2","10th","","1200","1"),
("5","1","11th","                                                            dfghjk                                                    ","1400","0"),
("6","1","one","dbvhsd","900","0"),
("7","1","two","jhjhbhj","900","0"),
("8","1","three","bhjghghj","900","0"),
("9","2","four","123","900","0"),
("10","1","five","fdbdg","900","0"),
("11","2","six","hjghj","1100","0"),
("12","1","seven","knkjnj","100","1"),
("13","2","8th","                              jhkhb                          ","1200","0"),
("14","2","9th","bhjgjh","1500","0"),
("15","2","10th","1545454","1500","0"),
("16","2","testing11","                              gbg                          ","2","1"),
("17","5","One","Nill","1000","0");--


--

CREATE TABLE `country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` text NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
INSERT INTO country VALUES
("1","pakistan1","0"),
("2","qwertyuiop","0");--


--

CREATE TABLE `district` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `province_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `is_delete` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
INSERT INTO district VALUES
("1","Lahore","0","0",""),
("2","Rahim yar khan","0","0","");--


--

CREATE TABLE `fee_def` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--


--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
INSERT INTO menu VALUES
("1","Admin","fa-users","0"),
("2","Branch","fa-building-o","0"),
("3","Teachers","fa-graduation-cap","0"),
("4","SMS","fa-envelope","0"),
("5","Class","fa-building-o","0"),
("6","Status","fa-building-o","1"),
("7","Section","fa-building-o","0"),
("8","Staff","fa-graduation-cap","0"),
("9","Student","fa-users","0"),
("10","Definition","fa-book","0"),
("11","Fee","fa-file-o","0"),
("12","Settings","fa-gear","0");--


--

CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`,`menu_id`,`submenu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=262 DEFAULT CHARSET=latin1;

--
INSERT INTO permission VALUES
("260","1","11","25"),
("259","1","11","24"),
("258","1","10","23"),
("257","1","10","22"),
("256","1","10","21"),
("255","1","10","20"),
("12","2","3","9"),
("11","2","3","8"),
("10","2","3","7"),
("13","2","4","10"),
("254","1","9","19"),
("253","1","9","18"),
("252","1","8","17"),
("208","3","10","23"),
("207","3","10","22"),
("206","3","10","21"),
("205","3","10","20"),
("204","3","9","19"),
("203","3","9","18"),
("202","3","8","17"),
("201","3","8","16"),
("200","3","7","15"),
("199","3","7","14"),
("198","3","5","12"),
("197","3","5","11"),
("196","3","4","10"),
("195","3","3","13"),
("194","3","3","9"),
("251","1","8","16"),
("250","1","7","15"),
("249","1","7","14"),
("193","3","3","8"),
("192","3","3","7"),
("191","3","2","6"),
("190","3","2","5"),
("248","1","5","12"),
("247","1","5","11"),
("246","1","4","10"),
("245","1","3","13"),
("244","1","3","9"),
("243","1","3","8"),
("242","1","3","7"),
("189","3","1","4"),
("188","3","1","3"),
("187","3","1","2"),
("186","3","1","1"),
("209","3","11","24"),
("210","3","11","25"),
("241","1","2","6"),
("240","1","2","5"),
("239","1","1","4"),
("238","1","1","3"),
("237","1","1","2"),
("236","1","1","1"),
("261","1","12","26");--


--

CREATE TABLE `province` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `province_name` text NOT NULL,
  `country_id` int(11) NOT NULL,
  `is_delete` int(11) DEFAULT '0',
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO province VALUES
("1","asdfghj4544","2","0"),
("2","jjkhj","1","0"),
("3","hjhjh","2","1");--


--

CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `remarks` varchar(500) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO role VALUES
("1","0","Super","This is super admin role","0"),
("2","1","Branch Head","branch manager account","0"),
("3","1","B.P","B.P","0");--


--

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `section_name` text NOT NULL,
  `description` text NOT NULL,
  `class_id` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
INSERT INTO section VALUES
("1","1","A","dfghj","12","1"),
("2","1","A","","11","0"),
("3","1","A","","13","0"),
("4","1","sd","bh","12","0"),
("5","1","rt","rt","12","0"),
("6","1","rt","rt","12","0"),
("7","1","k","kl","6","1"),
("8","5","A","Nill","17","0");--


--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `cnic` text NOT NULL,
  `contact` text NOT NULL,
  `salery` bigint(20) NOT NULL,
  `designation` text NOT NULL,
  `qualification` text NOT NULL,
  `dob` date NOT NULL,
  `doj` date NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
INSERT INTO staff VALUES
("1","1","Atif","Razzaq","","+923027566364","12000","sdfghjh","","2016-06-02","2016-06-15","Atif","0"),
("2","1","asdfgh","asdfgh","1234512345671","+923027566364","12","asdfg","","0001-01-01","0001-01-01","fghjk","0");--


--

CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
INSERT INTO status VALUES
("1","Left","the left the school","0"),
("2","abeer","                  present        ","0");--


--

CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grno` text NOT NULL,
  `roll_no` bigint(20) NOT NULL,
  `branch` int(11) NOT NULL,
  `student_name` text NOT NULL,
  `father_name` text NOT NULL,
  `surname` text NOT NULL,
  `gender` text NOT NULL,
  `guardian_name` text NOT NULL,
  `class` int(11) NOT NULL,
  `section` int(11) NOT NULL,
  `previous_school` text NOT NULL,
  `relation_with_guardian` text NOT NULL,
  `father_cnic` text NOT NULL,
  `guardian_cnic` text NOT NULL,
  `mark_identification` text NOT NULL,
  `religion` text NOT NULL,
  `mother_tongue` text NOT NULL,
  `dob` date NOT NULL,
  `date_of_admission` date NOT NULL,
  `taluka` text NOT NULL,
  `district` text NOT NULL,
  `father_occupation` text NOT NULL,
  `guardian_occupation` text NOT NULL,
  `income_family` text NOT NULL,
  `img` text NOT NULL,
  `perment_address` text NOT NULL,
  `postal_address` text NOT NULL,
  `father_contact` text NOT NULL,
  `student_contact` text NOT NULL,
  `guardian_contact` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
INSERT INTO student VALUES
("1","1","0","1","Atif Razzaq","3","4","Male","14","12","4","20","18","12","16","7","6","8","2016-06-09","0002-02-02","","","13","17","19","./images/56385765719609efd.png","12","123","11","5","15","0"),
("2","111","0","1","hjhjhjh","hjhjhjhj","jhjhjhj","Male","","11","4","","","1234512345671","","","islam","","2016-06-11","0001-01-01","3","2","","","","","lklklk","","+923027566364","","","0"),
("3","1234567","520163","5","Zakir","Sagheer","Bajwa","Male","Sagheer","17","8","Kids garden","Nill","3130349459479","1234566655433","Mole near eye","Islam","Urdu","1992-04-04","2016-05-22","3","1","Busines man","Nill","70000","./images/1506291947576a89d59aa97.jpg","Rahim yar khan","Nill","+923044550177","+923323929729","+923323929729","0"),
("4","1234","520164","5","shani","shabiir","bajwa","Male","sagher","17","8","kif","uncle","3130349459479","2343434345455","mole near eys","Islam","","2016-06-22","2016-06-01","4","2","Busines man","nill","80000","./images/413093061576ad63677c82.jpg","nill","nill","+923323939729","+923323929729","+923323882929","0");--


--

CREATE TABLE `submenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
INSERT INTO submenu VALUES
("1","All Users","admin/user/view","1","0"),
("2","Add User","admin/user/add","1","0"),
("3","Manage Roles","admin/role/manage","1","0"),
("4","Permissions","admin/permission/manage","1","0"),
("5","Add Branch","branch/add","2","0"),
("6","View Branch","branch/view","2","0"),
("7","Add Teacher","teacher/index","3","0"),
("8","View Teachers","teacher/show","3","0"),
("9","Teachers Status","teacher/status","3","0"),
("10","Manage API\'s","sms/api/manage","4","0"),
("11","Add Class","classes/create","5","0"),
("12","View Classes","classes/index","5","0"),
("13","View / ADD Status","status/index","3","0"),
("14","Add Section","section/create","7","0"),
("15","View Sections","section/index","7","0"),
("16","Add Staff","staff/index","8","0"),
("17","View Staff","staff/show","8","0"),
("18","Add Student","student/index","9","0"),
("19","View Student","student/show","9","0"),
("20","Country","country/index","10","0"),
("21","Province","province/index","10","0"),
("22","District","district/index","10","0"),
("23","City","city/index","10","0"),
("24","Fee Definition","fee/add","11","0"),
("25","Fee View","fee/view","11","0"),
("26","Backup","backup/index","12","0");--


--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `cnic` text NOT NULL,
  `contact` text NOT NULL,
  `salery` bigint(20) NOT NULL,
  `designation` text NOT NULL,
  `qualification` text NOT NULL,
  `specialization` text NOT NULL,
  `dob` date NOT NULL,
  `doj` date NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
INSERT INTO teacher VALUES
("1","1","","Razzaq","2147483647","2147483647","12000","Teacher","BSCS","WEB","1995-05-14","2016-06-15","                              0                          ","0","0"),
("2","5","Abeer","aasdad","1111111111111","+923404456731","-9","asdasdadssd","asdas","asdasddddddddddd","2016-06-04","2016-06-25","                          asdasdasdassssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss","0","0");--


--