

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact_no` varchar(20) NOT NULL,
  `role_id` int(11) NOT NULL DEFAULT '0',
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `role_id_2` (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO admin VALUES
("1","Sabeeh","Murtaza","sabeehmurtaza9","sabeehmurtaza9@gmail.com","505dd68d1d5f41f8148eebd83b29d58f","923159111969","1","0"),
("2","Baqir","Bajwa","baqir","baqirbajwa@yahoo.com","500f98179cacb15af39972bdd701646a","-00000000","2","0"),
("3","Atif","Razzaq","atif","atifrazzaqdashti@gmail.com","c6f057b86584942e415435ffb1fa93d4","3027566364","3","0");--


--

CREATE TABLE `api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--


--

CREATE TABLE `attendancestatus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
INSERT INTO attendancestatus VALUES
("1","P"),
("2","A"),
("3","L"),
("4","SL");--


--

CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `address` varchar(300) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `b_head` varchar(100) NOT NULL,
  `b_h_contact` varchar(20) NOT NULL,
  `c_person` varchar(200) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
INSERT INTO branch VALUES
("1","Branch 1","36,37, zainab tower, link road lahore ","000000000000","Branch Head","000000000000","Baqir Bajwa","0"),
("2","Branch 2","testing 123","-30","1212","123123","baqir","0"),
("3","hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh","hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh","-2222","hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh","hhhhhhhhhhhhhhhhhhhh","hhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhhh","0"),
("4","%%3..>,","&&**","123123","&&**^ %$%!@#","213123123","55%%^^&*","1"),
("5","1","1","1","1","1","1","0"),
("6","asd","1","1","asd","1","asdad","0");--


--

CREATE TABLE `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` text NOT NULL,
  `district_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `province_id` int(11) NOT NULL,
  `is_delete` int(11) DEFAULT '0',
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
INSERT INTO city VALUES
("1","Riwind","1","0","0","0"),
("2","shadra","1","0","0","0"),
("3","sadiq abad","2","0","0","0"),
("4","Rahim yar khan","2","0","0","0"),
("5","london","3","3","4","0");--


--

CREATE TABLE `class` (
  `class_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `class_name` text NOT NULL,
  `description` text NOT NULL,
  `tution_fee` bigint(20) NOT NULL,
  `admin_fee` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
INSERT INTO class VALUES
("1","2","10th","asdfg","1200","0","0"),
("2","2","10th","dfghjk","1200","0","0"),
("3","2","10th","","1200","0","1"),
("4","2","10th","","1200","0","1"),
("5","1","11th","                                                                                          dfghjk                                                                              ","-99","0","0"),
("6","1","one","dbvhsd","900","0","0"),
("7","1","two","jhjhbhj","900","0","0"),
("8","1","three","bhjghghj","900","0","0"),
("9","2","four","123","900","0","0"),
("10","1","five","fdbdg","900","0","0"),
("11","2","six","hjghj","1100","0","0"),
("12","1","seven","knkjnj","100","0","1"),
("13","2","8th","                              jhkhb                          ","1200","0","0"),
("14","2","9th","bhjgjh","1500","0","0"),
("15","2","10th","1545454","1500","0","0"),
("16","2","testing11","                              gbg                          ","2","0","1"),
("17","5","One","Nill","1000","0","0"),
("18","1","class 8","                              asdasdasda                          ","0","1222","0");--


--

CREATE TABLE `country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_name` text NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`country_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO country VALUES
("1","pakistan1","0"),
("2","qwertyuiop","0"),
("3","england","0");--


--

CREATE TABLE `district` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `province_id` int(11) NOT NULL,
  `country_id` int(11) NOT NULL,
  `is_delete` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO district VALUES
("1","Lahore","0","0",""),
("2","Rahim yar khan","0","0",""),
("3","london","4","3","");--


--

CREATE TABLE `fee_def` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `amount` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`),
  KEY `class_id` (`class_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO fee_def VALUES
("1","1","6","Paper fund","500","0"),
("2","1","6","Student Card","500","0"),
("3","1","18","pack","-98989","0");--


--

CREATE TABLE `fee_installment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice` int(11) NOT NULL,
  `fee_id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
INSERT INTO fee_installment VALUES
("3","1","3","9","0"),
("4","2","3","9","0");--


--

CREATE TABLE `invoice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `fee_pack` int(11) NOT NULL,
  `admin_fee` int(11) NOT NULL,
  `recieved` int(11) NOT NULL,
  `remaining` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  `date_expire` date NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
INSERT INTO invoice VALUES
("1","1","6","0","1222","0","0","0","2016-06-28","2016-07-08","0"),
("2","1","7","0","1222","0","0","0","2016-06-28","2016-07-08","0"),
("3","1","6","0","1222","0","0","0","2016-06-28","2016-07-08","0"),
("4","1","7","0","1222","0","0","0","2016-06-28","2016-07-08","0");--


--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `icon` varchar(50) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
INSERT INTO menu VALUES
("1","Admin","fa-users","0"),
("2","Branch","fa-building-o","0"),
("3","Teachers","fa-graduation-cap","0"),
("4","SMS","fa-envelope","0"),
("5","Class","fa-building-o","0"),
("6","Status","fa-building-o","1"),
("7","Section","fa-building-o","0"),
("8","Staff","fa-graduation-cap","0"),
("9","Student","fa-users","0"),
("10","Definition","fa-book","0"),
("11","Fee","fa-file-o","0"),
("12","Settings","fa-gear","0"),
("13","Attendance","fa-bar-chart","0"),
("14","Subject","fa-book","0");--


--

CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `submenu_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_id` (`admin_id`,`menu_id`,`submenu_id`)
) ENGINE=MyISAM AUTO_INCREMENT=744 DEFAULT CHARSET=latin1;

--
INSERT INTO permission VALUES
("706","1","14","37"),
("705","1","13","34"),
("704","1","13","33"),
("703","1","13","32"),
("702","1","13","31"),
("701","1","13","30"),
("742","2","14","37"),
("741","2","13","34"),
("740","2","13","33"),
("739","2","13","32"),
("700","1","13","29"),
("699","1","12","26"),
("698","1","11","40"),
("520","3","14","37"),
("519","3","13","34"),
("518","3","13","33"),
("517","3","13","32"),
("516","3","13","31"),
("515","3","13","30"),
("514","3","13","29"),
("513","3","12","26"),
("512","3","11","25"),
("511","3","11","24"),
("510","3","10","23"),
("509","3","10","22"),
("508","3","10","21"),
("507","3","10","20"),
("506","3","9","19"),
("697","1","11","39"),
("696","1","11","25"),
("695","1","11","24"),
("505","3","9","18"),
("504","3","8","17"),
("503","3","8","16"),
("502","3","7","15"),
("694","1","10","23"),
("693","1","10","22"),
("692","1","10","21"),
("691","1","10","20"),
("690","1","9","19"),
("689","1","9","18"),
("688","1","8","17"),
("501","3","7","14"),
("500","3","5","12"),
("499","3","5","11"),
("498","3","4","28"),
("497","3","4","27"),
("496","3","4","10"),
("687","1","8","16"),
("686","1","7","15"),
("685","1","7","14"),
("684","1","5","12"),
("683","1","5","11"),
("682","1","4","41"),
("681","1","4","28"),
("680","1","4","27"),
("679","1","4","10"),
("738","2","13","31"),
("737","2","13","30"),
("736","2","13","29"),
("735","2","12","26"),
("734","2","11","40"),
("733","2","11","39"),
("732","2","11","25"),
("731","2","11","24"),
("730","2","10","23"),
("729","2","10","22"),
("728","2","10","21"),
("727","2","10","20"),
("726","2","9","19"),
("725","2","9","18"),
("724","2","8","17"),
("723","2","8","16"),
("722","2","7","15"),
("721","2","7","14"),
("495","3","3","13"),
("494","3","3","9"),
("493","3","3","8"),
("492","3","3","7"),
("491","3","2","6"),
("490","3","2","5"),
("489","3","1","4"),
("488","3","1","3"),
("487","3","1","2"),
("678","1","3","13"),
("677","1","3","9"),
("676","1","3","8"),
("675","1","3","7"),
("674","1","2","6"),
("673","1","2","5"),
("486","3","1","1"),
("672","1","1","4"),
("671","1","1","3"),
("521","3","14","38"),
("720","2","5","12"),
("719","2","5","11"),
("718","2","4","41"),
("717","2","4","28"),
("716","2","4","27"),
("715","2","4","10");--
INSERT INTO permission VALUES
("714","2","3","13"),
("713","2","3","9"),
("712","2","3","8"),
("711","2","3","7"),
("710","2","1","4"),
("709","2","1","2"),
("708","2","1","1"),
("670","1","1","2"),
("669","1","1","1"),
("707","1","14","38"),
("743","2","14","38");--


--

CREATE TABLE `promotion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `is_active` int(11) NOT NULL DEFAULT '1',
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
INSERT INTO promotion VALUES
("5","5","6","7","1","1","0"),
("6","6","18","11","1","1","0"),
("7","7","18","11","1","1","0");--


--

CREATE TABLE `province` (
  `province_id` int(11) NOT NULL AUTO_INCREMENT,
  `province_name` text NOT NULL,
  `country_id` int(11) NOT NULL,
  `is_delete` int(11) DEFAULT '0',
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
INSERT INTO province VALUES
("1","asdfghj4544","2","0"),
("2","jjkhj","1","0"),
("3","hjhjh","2","1"),
("4","whales","3","0");--


--

CREATE TABLE `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `remarks` varchar(500) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `branch_id` (`branch_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO role VALUES
("1","0","Super","This is super admin role","0"),
("2","1","Branch Head","branch manager account","0"),
("3","1","B.P","B.P","0");--


--

CREATE TABLE `section` (
  `section_id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `section_name` text NOT NULL,
  `description` text NOT NULL,
  `class_id` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL,
  PRIMARY KEY (`section_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
INSERT INTO section VALUES
("1","1","A","dfghj","12","1"),
("2","1","A","","11","0"),
("3","1","A","","13","0"),
("4","1","sd","bh","12","0"),
("5","1","rt","rt","12","0"),
("6","1","rt","rt","12","0"),
("7","1","k","kl","6","0"),
("8","5","A","Nill","17","0"),
("9","1","atif","etc","5","0"),
("10","1","bbb","asdasdasd","18","1"),
("11","1","bb","asdad","18","0");--


--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `cnic` text NOT NULL,
  `contact` text NOT NULL,
  `salery` bigint(20) NOT NULL,
  `designation` text NOT NULL,
  `qualification` text NOT NULL,
  `dob` date NOT NULL,
  `doj` date NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO staff VALUES
("1","1","Atif","Razzaq","","+923027566364","12000","sdfghjh","","2016-06-02","2016-06-15","Atif","0"),
("2","1","asdfgh","asdfgh","1234512345671","+923027566364","12","asdfg","","0001-01-01","0001-01-01","fghjk","0"),
("3","5","umer","mehmood","1111111111111","+923333333333","-99999","TEACHER","bba","2016-06-02","2016-06-23","umer","0");--


--

CREATE TABLE `staffatt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
INSERT INTO staffatt VALUES
("1","1","2","2016-06-23","0"),
("2","2","1","2016-06-24","0");--


--

CREATE TABLE `status` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO status VALUES
("1","Left","the left the school","0"),
("2","abeer","                  present        ","0"),
("3","left","the one who left","0");--


--

CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `grno` text NOT NULL,
  `roll_no` bigint(20) NOT NULL,
  `branch` int(11) NOT NULL,
  `student_name` text NOT NULL,
  `father_name` text NOT NULL,
  `surname` text NOT NULL,
  `gender` text NOT NULL,
  `guardian_name` text NOT NULL,
  `previous_school` text NOT NULL,
  `relation_with_guardian` text NOT NULL,
  `father_cnic` text NOT NULL,
  `guardian_cnic` text NOT NULL,
  `mark_identification` text NOT NULL,
  `religion` text NOT NULL,
  `mother_tongue` text NOT NULL,
  `dob` date NOT NULL,
  `date_of_admission` date NOT NULL,
  `taluka` text NOT NULL,
  `district` text NOT NULL,
  `father_occupation` text NOT NULL,
  `guardian_occupation` text NOT NULL,
  `income_family` text NOT NULL,
  `img` text NOT NULL,
  `perment_address` text NOT NULL,
  `postal_address` text NOT NULL,
  `father_contact` text NOT NULL,
  `student_contact` text NOT NULL,
  `guardian_contact` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
INSERT INTO student VALUES
("1","1","0","1","Atif Razzaq","3","4","Male","14","20","18","12","16","7","6","8","2016-06-09","0002-02-02","","","13","17","19","./images/56385765719609efd.png","12","123","11","5","15","0"),
("2","111","0","1","hjhjhjh","hjhjhjhj","jhjhjhj","Male","","","","1234512345671","","","islam","","2016-06-11","0001-01-01","3","2","","","","","lklklk","","+923027566364","","","0"),
("3","1234567","520163","1","Zakir","Sagheer","Bajwa","Male","Sagheer","Kids garden","Nill","3130349459479","1234566655433","Mole near eye","Islam","Urdu","1992-04-04","2016-05-22","3","1","Busines man","Nill","70000","./images/1506291947576a89d59aa97.jpg","Rahim yar khan","Nill","+923044550177","+923323929729","+923323929729","0"),
("4","1234","520164","1","shani","shabiir","bajwa","Male","sagher","kif","uncle","3130349459479","2343434345455","mole near eys","Islam","","2016-06-22","2016-06-01","4","2","Busines man","nill","80000","./images/413093061576ad63677c82.jpg","nill","nill","+923323939729","+923323929729","+923323882929","0"),
("5","1122","0","1","Sabeeh Murtaza Mirza","Ammar Hasan Mirza","Mirza","Male","Ammar Hasan Mirza","Superior College","Father","1234567891233","1234567893333","nan","Islam","Urdu","1998-10-09","2016-06-25","1","1","Consultant","Consultant","25000","./images/719283165576ec6f981c0e.jpg","Islamabad","lahore","+923159111969","+923159111969","+923159111969","0"),
("6","1212","0","1","baqir","bajwa","asda","Male","rehan ahmed","helllo world","son","1111111111111","1111111111111","tongue","islam","asdasd","2016-06-16","2016-06-09","2","1","hoje","home","-9999","./images/1513197835577230d4e7827.jpg","asdas","asdasd","+923086754321","+924359876543","+923344556674","0"),
("7","121234","0","1","baqir","bajwa","asda","Male","rehan ahmed","helllo world","son","1111111111111","1111111111111","tongue","islam","asdasd","2016-06-16","2016-06-09","3","2","hoje","home","-9999","./images/310155998577231718feb0.jpg","asdas","asdasd","+923086754321","+924359876543","+923344556674","0");--


--

CREATE TABLE `studentatt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
INSERT INTO studentatt VALUES
("1","3","1","2016-06-24","1"),
("2","3","1","2016-06-24","0"),
("3","3","1","2016-06-25","0"),
("4","3","2","2016-06-25","0"),
("5","3","3","2016-06-28","0"),
("6","5","1","2016-06-28","0"),
("7","5","1","2016-06-28","0"),
("8","6","1","2016-06-28","0"),
("9","7","1","2016-06-28","0");--


--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `is_deleted` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
INSERT INTO subject VALUES
("1","0","6","7","1"),
("2","0","6","7","1"),
("3","english","6","7","1"),
("4","english1","6","7","1"),
("5","english1","0","0","0"),
("6","islamiate 12","5","9","1"),
("7","math","5","9","1"),
("8","urdu","5","9","0"),
("9","math2","5","9","0");--


--

CREATE TABLE `submenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `link` varchar(200) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
INSERT INTO submenu VALUES
("1","All Users","admin/user/view","1","0"),
("2","Add User","admin/user/add","1","0"),
("3","Manage Roles","admin/role/manage","1","0"),
("4","Permissions","admin/permission/manage","1","0"),
("5","Add Branch","branch/add","2","0"),
("6","View Branch","branch/view","2","0"),
("7","Add Teacher","teacher/index","3","0"),
("8","View Teachers","teacher/show","3","0"),
("9","Teachers Status","teacher/status","3","0"),
("10","Manage API\'s","sms/api/manage","4","0"),
("11","Add Class","classes/create","5","0"),
("12","View Classes","classes/index","5","0"),
("13","View / ADD Status","status/index","3","0"),
("14","Add Section","section/create","7","0"),
("15","View Sections","section/index","7","0"),
("16","Add Staff","staff/index","8","0"),
("17","View Staff","staff/show","8","0"),
("18","Add Student","student/index","9","0"),
("19","View Student","student/show","9","0"),
("20","Country","country/index","10","0"),
("21","Province","province/index","10","0"),
("22","District","district/index","10","0"),
("23","City","city/index","10","0"),
("24","Fee Definition","fee/add","11","0"),
("25","Fee View","fee/view","11","0"),
("26","Backup","backup/index","12","0"),
("27","SMS To Teachers","sms/view/teacher","4","0"),
("28","SMS To Students","sms/view/student","4","0"),
("29","Mark Student Attendance","student/studentatt_add","13","0"),
("30","View Student Attendance","student/studentatt_show","13","0"),
("31","Mark Teacher Attendance","Teacherattendancecr/index","13","0"),
("32","View Teacher Attendance","Teacherattendancecr/view","13","0"),
("33","Mark Staff Attendance","staff/staffatt_add","13","0"),
("34","View Staff Attendance","staff/staffatt_view","13","0"),
("37","Subject","subject/index","14","0"),
("38","Subject Assign To Teacher","subject/allocation","14","0"),
("39","Voucher Definition","voucher/index","11","0"),
("40","Voucher List","voucher/listv","11","0"),
("41","SMS To Absent Students","sms/view/absent","4","0");--


--

CREATE TABLE `teacher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch` int(11) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `cnic` text NOT NULL,
  `contact` text NOT NULL,
  `salery` bigint(20) NOT NULL,
  `designation` text NOT NULL,
  `qualification` text NOT NULL,
  `specialization` text NOT NULL,
  `dob` date NOT NULL,
  `doj` date NOT NULL,
  `address` text NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `is_delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
INSERT INTO teacher VALUES
("1","1","","Razzaq","2147483647","2147483647","12000","Teacher","BSCS","WEB","1995-05-14","2016-06-15","                              0                          ","0","0"),
("2","5","Abeer","aasdad","1111111111111","+923404456731","-9","asdasdadssd","asdas","asdasddddddddddd","2016-06-04","2016-06-25","                          asdasdasdassssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss","0","0"),
("3","1","Baiqr","Bajwa","1234567898765","+923333333333","-123123123","analysist","bsc","business","2016-06-22","2016-06-22","                              Baiqr                          ","0","0");--


--

CREATE TABLE `teacheralloc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `is_deleted` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
INSERT INTO teacheralloc VALUES
("22","1","9","5","9","0"),
("21","1","8","5","9","0"),
("20","1","7","5","9","0"),
("19","1","6","5","9","0"),
("18","1","4","6","7","0"),
("17","1","3","6","7","0"),
("16","1","2","6","7","0"),
("15","1","1","6","7","0"),
("14","1","6","5","9","0"),
("13","1","8","5","9","1");--


--

CREATE TABLE `teacherattendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `status_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `is_deleted` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
INSERT INTO teacherattendance VALUES
("1","1","2","2016-06-24","0"),
("2","2","1","2016-06-25","0");--


--