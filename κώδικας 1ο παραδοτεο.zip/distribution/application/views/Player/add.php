<style>
   @media screen and (max-width: 600px) {
    .col-md-6, input[type=submit] {
        width: 100%;
        margin-top: 0;
    }
} 
    
</style>
<link href="<?php echo base_url(); ?>assets/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Student Registration</h3>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Personal Information</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <?php if ($this->session->flashdata('suc_msg')): ?>
<div class="alert alert-success">
<?php echo $this->session->flashdata('suc_msg'); ?>
</div>
<?php endif ?>

<?php if ($this->session->flashdata('err_msg')): ?>
<div class="alert alert-danger">
<?php echo $this->session->flashdata('err_msg'); ?>
</div>
<?php endif ?>
                  <div class="x_content">

                    <form class="form-horizontal form-label-left" action="<?php echo base_url(); ?>Player/save" method="post" enctype="multipart/form-data">
                  
                      
                   <div class="row">
                       <div class="col-md-6">
                           <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">First Name</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                  <input id="first_name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="first_name" placeholder="First Name" required="required" type="text">
                               </div>
                             </div>   
                       </div>
                       <div class="col-md-6">
                           <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-2" for="address">Last Name</label>
                              <div class="col-md-6 col-sm-6 col-xs-5">
                                 <input type="text" id="last_name" name="last_name" placeholder="Last Name" class="form-control">
                              </div>
                           </div>   
                       </div>
                   </div>
                   
                   <div class="row">
                       <div class="col-md-6">
                           <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">Father Name</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                  <input id="father_name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="father_name" placeholder="Father Name" required="required" type="text">
                               </div>
                             </div>   
                       </div>
                       <div class="col-md-6">
                           <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-2" for="address">Father Contact</label>
                              <div class="col-md-6 col-sm-6 col-xs-5">
                                 <input type="text" id="father_contact" name="father_contact" placeholder="Father Contact No" class="form-control">
                              </div>
                           </div>   
                       </div>
                   </div>
                   
                   <div class="row">
                       <div class="col-md-6">
                           <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">Student Contact</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                  <input id="student_contact" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="student_contact" placeholder="Student Contact No" required="required" type="text">
                               </div>
                             </div>   
                       </div>
                       <div class="col-md-6">
                           <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-2" for="address">DOB</label>
                              <div class="col-md-6 col-sm-6 col-xs-5">
                                 <input  id="dob" name="dob" placeholder="Date Of Birth" class="form-control date">
                              </div>
                           </div>   
                       </div>
                   </div>
                   
                   <div class="row">
                       <div class="col-md-6">
                           <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">Email</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                  <input id="email" class="form-control col-md-7 col-xs-12" name="email" placeholder="Student Email" required="required" type="email">
                               </div>
                             </div>   
                       </div>
                       <div class="col-md-6">
                           <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-2" for="address">Class</label>
                              <div class="col-md-6 col-sm-6 col-xs-5">
                                 <input id="class" class="form-control col-md-7 col-xs-12" name="class" placeholder="Class In Which Admitted" required="required" type="text">
                              </div>
                           </div>   
                       </div>
                   </div>
                   
                   <div class="row">
                       <div class="col-md-6">
                           <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">Marital status</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                 <select name="marital_status" required class="form-control select2_single">
                                      <option value="">Select Option</option>
                                      <option value="Single">Single</option>
                                      <option value="Married">Married</option>
                                  </select>
                               </div>
                             </div>   
                       </div>
                       <div class="col-md-6">
                           <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-2" for="address">Location</label>
                              <div class="col-md-6 col-sm-6 col-xs-5">
                                 <textarea class="form-control col-md-7 col-xs-12" name="location"  required="required"></textarea>
                              </div>
                           </div>   
                       </div>
                   </div>
                   
                    <div class="row">
                       <div class="col-md-6">
          
                              <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">From Other City</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                 <select name="other_city" required class="form-control select2_single">
                                      <option value="">Select Option</option>
                                      <option value="Yes">Yes</option>
                                      <option value="No">No</option>
                                  </select>
                               </div>
                             </div> 
                             
                       </div>
                       
                       <div class="col-md-6">
                           <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">Siblings</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                 <input id="siblings" class="form-control col-md-7 col-xs-12" name="siblings"  required="required" type="number">
                               </div>
                             </div>   
                       </div>
                       
                   </div>
                   
                   <div class="row">
                       <div class="col-md-6">
          
                              <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">Department</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                 <select name="department" required class="form-control select2_single">
                                      <option value="">Select Option</option>
                                      <?php
                                      $deprtments=$this->db->select('*')
                                                           ->from('department')
                                                           ->where('is_delete',0)
                                                           ->get()->result_array();
                                      if(!empty($deprtments))  
                                      {foreach($deprtments as $row){?>
                                              <option value="<?php echo $row['id']?>"><?php echo $row['name'];?></option>
                                      <?php    }} ?>
                                  </select>
                               </div>
                             </div> 
                             
                       </div>
                    </div>

              <div class="ln_solid"></div>
                <h2>Financial  Information</h2>   

                     <div class="row">
                       <div class="col-md-6">
                           <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-1 col-xs-1" for="name">Student Income</label>
                               <div class="col-md-6 col-sm-6 col-xs-5">
                                 <input id="student_income" class="form-control col-md-7 col-xs-12" name="student_income" placeholder="Income Of Student" required="required" type="number">
                               </div>
                             </div>   
                       </div>
                       <div class="col-md-6">
                           <div class="item form-group">
                              <label class="control-label col-md-3 col-sm-2 col-xs-2" for="address">Parents Income</label>
                              <div class="col-md-6 col-sm-6 col-xs-5">
                                 <input id="parent_income" class="form-control col-md-7 col-xs-12" name="parent_income" placeholder="Income Of Parents" required="required" type="number">
                              </div>
                           </div>   
                       </div>
                   </div>
                   
                   
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-3 col-md-offset-9 model-footer">
                          <button id="send" type="submit" class="btn btn-success">Register</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        
        <!-- /footer content -->
      </div>
    </div>

       
   <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/vendors/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/select2/dist/js/select2.full.min.js"></script>
   
<footer>
          <div class="pull-right">
            Distribution
          </div>
          <div class="clearfix"></div>
        </footer>
        <div id='ajaxload' style='position:fixed;top:0;left:0;bottom:0; width:100%;height:100%;z-index:1000;background:rgba(2,132,130,0.5);display:none;'>
            <i class='fa fa-spinner fa-spin fa-4x' style='position: relative;top: 50%;left: 50%;margin-top: -50px;margin-left: -50px;'></i>
        </div>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    
    <!-- Custom JS -->
    <script src="<?php echo base_url(); ?>assets/js/main.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php echo base_url(); ?>assets/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="<?php echo base_url(); ?>assets/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo base_url(); ?>assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="<?php echo base_url(); ?>assets/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.orderBars.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/date.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.spline.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/curvedLines.js"></script>
    <!-- jVectorMap -->
    <script src="<?php echo base_url(); ?>assets/js/maps/jquery-jvectormap-2.0.3.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url(); ?>assets/js/moment/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/build/js/custom.min.js"></script>
          <script src="<?php echo base_url(); ?>assets/js/bootstrap-datepicker.js"></script>
<script>

$(document).ajaxStart(function() {
          $('#ajaxload').show();
      });
      $(document).ajaxStop(function() {
           $('#ajaxload').hide();
      });
 $(function () {
    $(".date").datepicker({format: 'dd/mm/yyyy'});
    date(".now");
    $(".date").focusout(function () {
        if ($(this).val().trim() == "") {
            date(".date");
        }
    });

    function date(selector) {
        var dNow = new Date();
        var localdate = dNow.getFullYear()+'/' +(dNow.getMonth() + 1)+'/' + dNow.getDate();
       
    }

});
</script>
    <script>
    $("#offer").on("change",function(event){
        var value=$(this).val();
        if(value=="Yes")
        {
            $("#ofer_text").show();
        }else
        {
           $("#ofer_text").hide(); 
        }
    });
    
    $(".abc").on("keypress", function (event) {

            var englishAlphabetAndWhiteSpace = /[A-Za-z ]/g;


            var key = String.fromCharCode(event.which);


            if (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 37 || event.keyCode == 39 || englishAlphabetAndWhiteSpace.test(key)) {
                return true;
            }
            return false;
        });

         $('.abc').on("paste", function (e) {
            e.preventDefault();
        });
        $(".abc1").on("keypress", function (event) {

            var englishAlphabetAndWhiteSpace = /[A-Za-z0-9|-]/g;


            var key = String.fromCharCode(event.which);


            if (event.keyCode == 8 || event.keyCode == 9 || event.keyCode == 32 || event.keyCode == 37 || event.keyCode == 39 || englishAlphabetAndWhiteSpace.test(key)) {
                return true;
            }


            return false;
        }); $('.abc1').on("paste", function (e) {
            e.preventDefault();
        });
        $(document).bind("contextmenu", function (e) {
            e.preventDefault();
        });
         //form only numbers
        $(".num").on("keypress", function (e) {
          
            var evt = (e) ? e : window.event;
            var charCode = (evt.keyCode) ? evt.keyCode : evt.which;
            if (charCode > 31 && (charCode < 48 || charCode > 57)) {
                return false;
            }
            return true;
        });
         $(".select2_single").select2({
            placeholder: "Select Option",
            allowClear: true
         });
    </script>
    <script>
window.setTimeout(function() {
$(".alert").fadeTo(500, 0).slideUp(500, function(){
    $(this).remove(); 
});
}, 3000);
    </script>
  </body>
</html>
  
  </body>
</html>