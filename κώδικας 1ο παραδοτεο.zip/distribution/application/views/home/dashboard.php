<style>
  .my_dashboard_tiles .tile_stats_count:nth-child(7):before {
      border-left: 0 !important;
  }
  .my_dashboard_tiles .tile_stats_count:nth-child(13):before {
      border-left: 0 !important;
  }
  .my_dashboard_tiles .tile_stats_count:nth-child(19):before {
      border-left: 0 !important;
  }
  .fa-stack-2x {
    color:#D2691E;
    margin-left:150px;
}
</style>
        <!-- page content -->
        <div class="right_col" role="main">
         
          <!-- top tiles -->
         
          <!-- /top tiles -->

<!--Graphs-->
<div class="row ">




</div><!--row-->




   <div class="clearfix"></div>
                  </div>

               <footer>
          <div class="pull-right">
            Distribution
          </div>
         <div class="clearfix"></div>
        </footer> 
  

    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo base_url(); ?>assets/js/main.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php echo base_url(); ?>assets/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="<?php echo base_url(); ?>assets/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo base_url(); ?>assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="<?php echo base_url(); ?>assets/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.orderBars.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/date.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.spline.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/curvedLines.js"></script>
    <!-- jVectorMap -->
    <script src="<?php echo base_url(); ?>assets/js/maps/jquery-jvectormap-2.0.3.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url(); ?>assets/js/moment/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/build/js/custom.min.js"></script>

<script>
      $(document).ready(function(){
        var options = {
          legend: false,
          responsive: false
        };

        new Chart(document.getElementById("canvas1"), {
          type: 'doughnut',
          tooltipFillColor: "rgba(51, 51, 51, 0.55)",
          data: {
            labels: [
               <?php
             foreach ($top_comp as $value)
                    {?>
"<?php echo $value['name'];?>",
                 <?php   }?>
            ],
            datasets: [{
              data: [
     <?php
        
foreach ($top_comp as  $value) { 
            echo $value['mid'];
            echo ",";
}?>
              ],
              backgroundColor: [
                "#fddf59",
                "#9B59B6",
                "#E74C3C",
                "#26B99A",
                "#3498DB",
                "#D2691E"
                
              ],
              hoverBackgroundColor: [
                "#fddf59",//left
                "#B370CF",
                "#E95E4F",
                "#36CAAB",
                "#49A9EA"
              ]
            }]
          },
          options: options
        });
      });
    </script>

    <script>
      $(document).ready(function(){
        var options = {
          legend: false,
          responsive: false
        };

        new Chart(document.getElementById("canvas2"), {
          type: 'doughnut',
          tooltipFillColor: "rgba(51, 51, 51, 0.55)",
          data: {
            labels: [
               <?php
             foreach ($vndors as $value)
                    {?>
"<?php echo $value['name'];?>",
                 <?php   }?>
            ],
            datasets: [{
              data: [
     <?php
        
foreach ($vndors as  $value) { 
            echo $value['mid'];
            echo ",";
}?>
              ],
              backgroundColor: [
                "#34495e",
                "#d2691e",
                "#928584",
                "#e8c1c6",
                "#43ffe2"
                
                
              ],
              hoverBackgroundColor: [
                "#34495e",//left
                "#d2691e",
                "#928584",
                "#e8c1c6",
                "#43ffe2"
              ]
            }]
          },
          options: options
        });
      });
    </script>
   
    <!-- /gauge.js -->
  </body>
</html>