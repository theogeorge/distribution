
<link href="<?php echo base_url(); ?>assets/vendors/select2/dist/css/select2.min.css" rel="stylesheet">
 <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Profile</h3>
                </div>
            </div>
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Edit Profile</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
             
                  <div class="x_content">

                    <form class="form-horizontal form-label-left" action="<?php echo base_url(); ?>User/update_profile" method="post" enctype="multipart/form-data">
                      

                      <div class="item form-group">
                        <label class="control-label col-md-1 col-sm-1 col-xs-1" for="name">Name <span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-6 col-xs-5">
                          <input id="name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6"
                           data-validate-words="2" name="name" value="<?php echo $com['first_name'];?>" placeholder="Name" required="required" type="text">
                        </div>
                      <!--</div>-->
                      <!--<div class="item form-group">-->
                        <label class="control-label col-md-2 col-sm-2 col-xs-1" for="address">User Name<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-6 col-xs-5">
             <input id="u_name" class="form-control col-md-7 col-xs-12" 
                  name="u_name" value="<?php echo $com['username'];?>" placeholder="User Name" required="required" type="text">
                        </div>
                      </div>
                      

                      <div class="item form-group">
                        <label class="control-label col-md-1 col-sm-2 col-xs-1" for="contact">Password<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-6 col-xs-5">
                          <input type="password" id="pass" name="pass" value="<?php echo $com['password'];?>" required="required" data-validate-minmax="10,100" class="form-control col-md-7 col-xs-12" placeholder="Contact Number Primary">
                        </div>
                      <!--</div>

                        <div class="item form-group">-->
                        <label class="control-label col-md-2 col-sm-1 col-xs-1" for="contact">Contact<span class="required">*</span>
                        </label>
                        <div class="col-md-4 col-sm-6 col-xs-5">
                          <input type="number" id="contact_sec" name="contact_sec" value="<?php echo $com['contact_no'];?>" required="required" data-validate-minmax="10,100" class="form-control col-md-7 col-xs-12"
                           placeholder="Contact Number Secondary">
                        </div>
                      </div>
                      
                  <div class="item form-group">
                        <label for="password" class="control-label col-md-1 col-sm-1 col-xs-1">Email <span class="required">*</span></label>
                        <div class="col-md-4 col-sm-6 col-xs-5">
                          <input id="email" type="email" name="email" value="<?php echo $com['email'];?>" placeholder="Email" class="form-control col-md-7 col-xs-12" required="required">
                        </div>
                
                      </div>
    
                     
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                          <button id="send" type="submit" class="btn btn-success">Update</button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <footer>
          <div class="pull-right">
            DREAMS
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

 <!--<script src="<?php echo base_url(); ?>assets/vendors/jquery/dist/jquery.min.js"></script>-->
        <!--<script src="<?php echo base_url(); ?>assets/vendors/select2/dist/js/select2.full.min.js"></script>-->
       
   <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo base_url(); ?>assets/js/main.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo base_url(); ?>assets/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo base_url(); ?>assets/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php echo base_url(); ?>assets/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="<?php echo base_url(); ?>assets/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo base_url(); ?>assets/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo base_url(); ?>assets/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="<?php echo base_url(); ?>assets/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.orderBars.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/date.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/jquery.flot.spline.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/flot/curvedLines.js"></script>
    <!-- jVectorMap -->
    <script src="<?php echo base_url(); ?>assets/js/maps/jquery-jvectormap-2.0.3.min.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo base_url(); ?>assets/js/moment/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/datepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo base_url(); ?>assets/build/js/custom.min.js"></script>

  
       <script>
window.setTimeout(function() {
$(".alert").fadeTo(500, 0).slideUp(500, function(){
    $(this).remove(); 
});
}, 3000);
    </script>
  </body>
</html>