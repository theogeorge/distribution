<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Admin | Panel</title>

    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url(); ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="https://colorlib.com/polygon/gentelella/css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="<?php echo base_url(); ?>assets/build/css/custom.min.css" rel="stylesheet">
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
<?php if ($this->session->flashdata('err_msg')): ?>
<div class="alert alert-danger">
<?php echo $this->session->flashdata('err_msg'); ?>
</div>
<?php endif ?>
          <section class="login_content">
            <form action="<?php echo base_url(); ?>Front/reset" method="post">
              <div>
                <h1>Distribution</h1>
              </div>
              <div class="separator">
              </div>
              <div class="clearfix"></div>
              <div>
                <input type="text" name="email" class="form-control" placeholder="Registred Email" required="" />
              </div>
              <div>
                <input type="text" name="username" class="form-control" placeholder="Username" required="" />
              </div>
              <div>
                <input type="password" name="password" class="form-control" placeholder="New Password" required="" />
              </div>
              <div>
                <button class="btn btn-default submit" type="submit">Reset</button>

              </div>
              <div class="clearfix"></div>

              

              <div class="clearfix"></div>

            </form>
          </section>
        </div>

      </div>
    </div>
    
    <!-- jQuery -->
    <script src="<?php echo base_url(); ?>assets/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Custom JS -->
    <script src="<?php echo base_url(); ?>assets/js/main.js"></script>
    <script>
window.setTimeout(function() {
$(".alert").fadeTo(500, 0).slideUp(500, function(){
    $(this).remove(); 
});
}, 3000);
    </script>
  </body>
</html>