<?php

if (!defined('BASEPATH'))
    exit('No direct script  allow');
 
class Generic_model extends CI_Model {
   public function getStudentCard(){
 $this->load->model('user_model'); 
   //  print_r($startd);die();
     $branchid= $this->user_model->getBranch();
        $this->db->select('s.id as id,s.student_name as student_name,s.father_name as father_name,s.grno as grno,s.date_of_admission as date_of_admission,s.father_contact as father_contact,s.img as img,c.class_name as cname')
        ->from('student as s')
        ->join('promotion as p','p.student_id=s.id')
        ->join('class as c','p.class_id=c.class_id')
  
   //     ->join('class as c','c.class_id=p.class_id', 'left')
   //     ->join('leave_info as l','l.std_id=s.id', 'left')
        
        //->join('certificate_issued as c', 'c.std_id = s.id', 'left')
     //   ->join('client as c', 'c.id = f.client_id')
        
        // ->where(array('s.is_delete'=>0,'s.branch'=>$branchid))
        ->where(array('s.is_delete'=>0,'s.status'=>0,'p.is_active'=>1,'p.is_delete'=>0,'s.branch'=>2))
        ->order_by("s.id","DESC");
        //   ,l.dol BETWEEN "'. date('Y-m-d', strtotime($startd)). '" and "'. date('Y-m-d', strtotime($endd)).'"'
        $w=$this->db->get();
        if ($w->num_rows() > 0){
        return $w->result_array();}
        else {return FALSE; }
    }
     
     public function getStudentRegisteration(){
 $this->load->model('user_model'); 
   //  print_r($startd);die();
     $branchid= $this->user_model->getBranch();
        $this->db->select('s.id as id,s.student_name as name,c.class_name as cname')
        ->from('student as s')
        ->join('promotion as p','p.student_id=s.id')
        ->join('class as c','p.class_id=c.class_id')
  
   //     ->join('class as c','c.class_id=p.class_id', 'left')
   //     ->join('leave_info as l','l.std_id=s.id', 'left')
        
        //->join('certificate_issued as c', 'c.std_id = s.id', 'left')
     //   ->join('client as c', 'c.id = f.client_id')
        
        // ->where(array('s.is_delete'=>0,'s.branch'=>$branchid))
        ->where(array('s.is_delete'=>0,'p.is_active'=>1,'p.is_delete'=>0,'s.branch'=>$branchid))
        ->order_by("s.id","DESC");
        //   ,l.dol BETWEEN "'. date('Y-m-d', strtotime($startd)). '" and "'. date('Y-m-d', strtotime($endd)).'"'
        $w=$this->db->get();
        if ($w->num_rows() > 0){
        return $w->result_array();}
        else {return FALSE; }
    }
     
      public function getLeftStudent($classid){
 $this->load->model('user_model'); 
   //  print_r($startd);die();
     $branchid= $this->user_model->getBranch();
        $this->db->select('c.class_id as cid,s.student_name as name,c.class_name as cname')
        ->from('promotion as p')
        ->join('class as c','c.class_id=p.class_id')
        ->join('student as s','s.id=p.student_id');
  
   //     ->join('class as c','c.class_id=p.class_id', 'left')
   //     ->join('leave_info as l','l.std_id=s.id', 'left')
        
        //->join('certificate_issued as c', 'c.std_id = s.id', 'left')
     //   ->join('client as c', 'c.id = f.client_id')
        
        // ->where(array('s.is_delete'=>0,'s.branch'=>$branchid))
        if($branchid==1)
        $this->db->where(array('s.status'=>21,'p.is_delete'=>0,'s.branch'=>$branchid));
        elseif($branchid==2)
        $this->db->where(array('s.status'=>23,'p.is_delete'=>0,'s.branch'=>$branchid));
        $this->db->order_by("s.id","DESC");
        //   ,l.dol BETWEEN "'. date('Y-m-d', strtotime($startd)). '" and "'. date('Y-m-d', strtotime($endd)).'"'
        $this->db->where(array('p.class_id'=>$classid));
        $w=$this->db->get();
        if ($w->num_rows() > 0){
        return $w->num_rows();}
        else {return 0; }
    }
     public function getExpellStudent($classid){
 $this->load->model('user_model'); 
   //  print_r($startd);die();
     $branchid= $this->user_model->getBranch();
        $this->db->select('c.class_id as cid,s.student_name as name,c.class_name as cname')
        ->from('promotion as p')
        ->join('class as c','c.class_id=p.class_id')
        ->join('student as s','s.id=p.student_id');
  
   //     ->join('class as c','c.class_id=p.class_id', 'left')
   //     ->join('leave_info as l','l.std_id=s.id', 'left')
        
        //->join('certificate_issued as c', 'c.std_id = s.id', 'left')
     //   ->join('client as c', 'c.id = f.client_id')
        
        // ->where(array('s.is_delete'=>0,'s.branch'=>$branchid))
        if($branchid==1)
        $this->db->where(array('s.status'=>24,'p.is_delete'=>0,'s.branch'=>$branchid));
        elseif($branchid==2)
        $this->db->where(array('s.status'=>24,'p.is_delete'=>0,'s.branch'=>$branchid));
        $this->db->order_by("s.id","DESC");
        //   ,l.dol BETWEEN "'. date('Y-m-d', strtotime($startd)). '" and "'. date('Y-m-d', strtotime($endd)).'"'
        $this->db->where(array('p.class_id'=>$classid));
        $w=$this->db->get();
        if ($w->num_rows() > 0){
        return $w->num_rows();}
        else {return 0; }
    }
    public function getPassOutStudent($classid){
 $this->load->model('user_model'); 
   //  print_r($startd);die();
     $branchid= $this->user_model->getBranch();
        $this->db->select('c.class_id as cid,s.student_name as name,c.class_name as cname')
        ->from('promotion as p')
        ->join('class as c','c.class_id=p.class_id')
        ->join('student as s','s.id=p.student_id');
  
   //     ->join('class as c','c.class_id=p.class_id', 'left')
   //     ->join('leave_info as l','l.std_id=s.id', 'left')
        
        //->join('certificate_issued as c', 'c.std_id = s.id', 'left')
     //   ->join('client as c', 'c.id = f.client_id')
        
        // ->where(array('s.is_delete'=>0,'s.branch'=>$branchid))
        if($branchid==1)
        $this->db->where(array('s.status'=>31,'p.is_delete'=>0,'s.branch'=>$branchid));
        elseif($branchid==2)
        $this->db->where(array('s.status'=>31,'p.is_delete'=>0,'s.branch'=>$branchid));
        $this->db->order_by("s.id","DESC");
        //   ,l.dol BETWEEN "'. date('Y-m-d', strtotime($startd)). '" and "'. date('Y-m-d', strtotime($endd)).'"'
        $this->db->where(array('p.class_id'=>$classid));
        $w=$this->db->get();
        if ($w->num_rows() > 0){
        return $w->num_rows();}
        else {return 0; }
    }
     
     
     public function getAllStudent(){
     $branchid= $this->user_model->getBranch();
        $this->db->select('s.id as id,s.branch as branch,s.dol as dol,s.grno as grno,s.class_admited as class_admited,s.student_name as name,s.father_name as father_name,s.surname as surname,s.previous_school as previous_school,s.religion as religion,s.dob as dob,s.pob as pob,s.date_of_admission as date_of_admission,s.remarks as remarks,l.progress as progress,l.class_in_which_left as class_in_which_left,l.conduct as conduct,c.date as certificate_date')
        ->from('student as s')
        ->join('leave_info as l','s.id=l.std_id', 'left')
        ->join('certificate_issued as c', 'c.std_id = s.id', 'left')
     //   ->join('client as c', 'c.id = f.client_id')
        
        ->where(array('s.is_delete'=>0,'s.branch'=>$branchid))
        ->order_by("s.id","DESC");
        
        $w=$this->db->get();
        if ($w->num_rows() > 0){
        return $w->result_array();}
        else {return FALSE; }
    } 
    function save($data) 
    {
        $this->db->insert('income', $data);
        if ($this->db->insert_id()>0)
            return TRUE;
        return FALSE;
    
    }
	
	
	 function getAllRecordss($table,$by,$where) {
        $this->db->select()->from($table)->where($where)->order_by($by);
        $query=$this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    function insert($table, $data) {
        $this->db->insert($table, $data);
        if ($this->db->insert_id() > 0)
            return $this->db->insert_id();
        else
            return FALSE;
    }
    function getAllRecords($table,$where,$by,$order) {
        $this->db->select()->from($table)->where($where)->order_by($by,$order);
        $query=$this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    function getAllRecordsLike($table,$where,$colm,$like,$by,$order) {
        $this->db->select()->from($table)->where($where)->like($colm,$like)->order_by($by,$order);
        $query=$this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    function getAllRecordsbyLimit($table,$where,$by,$order,$limit,$start) {
        $this->db->select()->from($table)->where($where)->order_by($by,$order)->limit($limit , $start);
        $query=$this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    function getSpecificRecord($table,$where) {
        $this->db->select()->from($table)->where($where);
        $query=$this->db->get();
        if ($query->num_rows() > 0)
        {
            $result= $query->result_array();
            return $result[0];
        }  
        else
        {return FALSE;}
            
    }
    public function updateRecord($table,$set, $where) {
        $this->db->update($table, $set, $where);
        if ($this->db->affected_rows() > 0)
            return TRUE;
        else 
            return FALSE;
    }
    public function delete($table,$where){ 
        
        $this->db->where($where);
        $this->db->delete($table); 
    }
    public function getMaxId($table){ 
       $query=$this->db->query("SELECT max(id) as max FROM $table ");
        
        if ($query->num_rows() > 0){
             $result= $query->result_array();
            return $result[0];
        }
        else{
            return FALSE;
    }
    }
    public function getCount($table,$where){ 
       $query=$this->db->query("SELECT count(id) as count FROM $table $where");
        
        if ($query->num_rows() > 0){
             $result= $query->result_array();
            return $result[0];
        }
        else{
            return FALSE;
    }
    }
    
    function getSpecificMaxId($table,$where,$coloumn)
    {
        $this->db->select_max("$coloumn")
        ->from($table)->where($where);
        $query = $this->db->get();
        if ($query->num_rows() > 0)
        {
            $result= $query->result_array();
            return $result[0];
        }
        else
        {
            return FALSE;
        }
    }
    
    function get_distinct($table,$field) 
    {
        $this->db->select("DISTINCT($field)")->from($table)->order_by($field,"ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    
    function get_distinctwhere($table,$field,$where) 
    {
        $this->db->select("DISTINCT($field)")->from($table)->where($where)->order_by($field,"ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    function getData($table,$fields,$where,$by) 
    {
        $this->db->select("$fields")->from($table)->where($where)->order_by($by,"ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    public function extra() 
    {
        $this->db->select('lhw.id as LhwId,lhw.name as LHW Name,lhw.phone as Phone, vill.village as Village, count(sub.id) as SujectForms')
            ->from('dekho_lhw as lhw')
            ->join('dekho_villages As vill','lhw.parentId=vill.id')
            ->join('subjects As sub','sub.lhw=lhw.id')
            ->where(array(
                'vill.assignment'=>1,
                'vill.status'=>1,
                'sub.is_deleted' => 0,
                'lhw.status'=>1,
               ))
            ->group_by('lhw.id');
        $query = $this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    function getSubjects()
	{
        $this->db->select("sub.language,sub.msgReceivingTime,cal.id as recordId,cal.message,cal.arm,cal.system_week,cal.subjectId")
            ->from('call_record as cal')
            ->join('subjects As sub','cal.subjectId=sub.id')
            ->where(array(
                "cal.system_week"=>14,
                "cal.is_deleted"=>0
               ));
            
        $query = $this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    //$table,$by,$where
	public function program($where) 
    {
		$this->db->select('incs.id,incs.channel as channel,incs.item as Item,incs.name as Name,  incs.cashPromised as CashPromised, incs.cashReceived as cashReceived, incs.cashRemaining as cashRemaining,st.name as status , us.firstName as Client, used.firstName as Agent')
        
        ->from('income as incs')
        ->join('users as us', 'us.id = incs.client')
        ->join('status as st', 'incs.status = st.id')
        ->join('users as used', 'used.id = incs.agent')
        ->where(array('incs.item' => $where,'incs.is_deleted'=>0))
        ->order_by("incs.id","DESC");
        
        $query=$this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
		
    }
public function advertisementt($where)
		{
			$this->db->select('inc.id,inc.channel as channel,inc.item as Item,inc.name as Name,inc.cashPromised as CashPromised,inc.cashReceived as CashReceived,inc.cashRemaining as cashRemaining ')
			->from('income as inc')
			->join('users as us','us.id=inc.client')
			->join('status as st','inc.status=st.id')
			->where(array('inc.item'=>$where,'inc.is_deleted'=>0))
			->order_by("inc.id","DESC");
			$query=$this->db->get();
			if($query->num_rows()>0)
			return $query->result_array();
			else
			return FALSE;
			}

public function officeexpense($where) 
    {
		$this->db->select('exp.id,exp.expenseOn as expenseOn,exp.paymentTo as paymentTo,exp.detail as detail,exp.cash as cash, us.firstName as employee')
        
        ->from('expense as exp')
        ->join('users as us', 'us.id = exp.paymentTo')
        ->join('status as st', 'exp.status = st.id')
        
        ->where(array('exp.expenseOn' => $where,'exp.is_deleted'=>0))
        ->order_by("exp.id","DESC");
        
        $query=$this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
		
    }
    function extra1() 
    {
        $this->db->select('is.district_center as district,dis.uniqueId as districtId,cen.district_center as tehsil,cen.uniqueId as tehsilid,un.union as unionName,un.unionId,vill.village,vill.villageId,vill.assignment as Assignment,lhw.name as LhwName,lhw.phone as Phone')
        ->from('dekho_lhw as lhw')
        ->join('dekho_villages As vill','lhw.parentId=vill.id')
        ->join('dekho_union As un','vill.unionId=un.id')
        ->join('dekho_districts As cen','vill.centerId=cen.id')
        ->join('dekho_districts As dis','cen.parentId=dis.id')
        ->where(array(
            "lhw.status"=>1,
        ));
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $result= $query->result_array();
        } else {
           return FALSE;
        }
    }
    function get_distinct_all_fields($table,$field) 
    {
        $this->db->select("DISTINCT($field),phone_number,preg_week")->from($table)->order_by($field,"ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    function get_all_fields_distinctwhere($table,$field,$where) 
    {
        $this->db->select("DISTINCT($field)")->from($table)->where($where)->order_by($field,"ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0)
            return $query->result_array();
        else
            return FALSE;
    }
    function getSpecificMaxResult($table,$where)
    {
        $this->db->select("Max(start_date_time) as start_date_time, campaign_name,msg,subjectId,name,preg_week,phone_number,attempts,first_audio_file,status,duration,system_week")
        ->from($table)->where($where);
        $query = $this->db->get();
        ;if ($query->num_rows() > 0)
        {
            $result= $query->result_array();
            return $result[0];
        }
        else
        {
            return FALSE;
        }
    }
    function getCalls($subId)
	{
        $query=$this->db->query("SELECT * FROM `call_record` WHERE `subjectId` = $subId and date_of_call=(select min(date_of_call) from call_record where subjectId=$subId and date_of_call != '0000-00-00') ORDER BY `date_of_call` ASC");
        
        if ($query->num_rows() > 0){
            $result= $query->result_array();
            return $result[0];
        }
        else{
            return FALSE;}
    }
     
}