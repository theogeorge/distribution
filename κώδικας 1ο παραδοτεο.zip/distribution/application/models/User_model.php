<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class User_model extends CI_Model {

	public function __construct()
	{
	parent::__construct();
	$this->load->library("smsgateway");
	}
    
    public function fetch_subject($c,$s)
	{
	 return $this->db->where('class_id',$c)->where('section_id',$s)->from('subject')->get()->result();
 
	
	
	}
	

	public function login($u="",$p="")
	{
	
        if($u=="" OR $p=="")
            return "Empty Username/Password";
        $pass = md5($p);
        $query = $this->db->query("SELECT * FROM `admin` WHERE `username`='$u' 
        AND `password`='$pass' AND  is_delete='0'")->row_array();
               // var_dump( $query);die();
        
        if(count($query)>0)
        {
           
            $id = $query['id'];
            $this->session->admin = base64_encode(json_encode(array('id' => $id, 'username' => $u)));
            
            $this->sendDetails($u);
            $spp=5;
            return $spp;
         
            
        }else{
            $sp=01;
            return $sp;
        }
	}



	public function portal_login($u="",$p="")
	{
         // echo "hello";die();
        if($u=="" OR $p=="")
            return "Empty Username/Password";
         $pass = md5($p);
        $query = $this->db->query("SELECT * FROM `admin` WHERE `username`='$u' AND `password`='$pass' AND (student_id >'0' OR teacher_id > '0') AND is_delete='0'")->row_array();
        
        //var_dump($query);die();
        if(count($query)>0)
        {
           
          $student_id = $query['student_id'];
           $teacher_id = $query['teacher_id'];
            $id = $query['id'];
            $this->session->admin = base64_encode(json_encode(array('id' => $id, 'username' => $u)));
            
            $this->sendDetails($u);
            
             redirect("User/index","refresh");
            
        }else{
            echo "Invalid Credientials";
        }
	}



    public function logout()
	{
    
	$this->session->admin = array();
        redirect("User");
	  
	}
	
	
   public function portal_logout()
	{

	 $this->session->admin = array();
         redirect("Portal/User");      
	}
    
    public function check_login($p="")
	{
        if($p=="")
            die("Empty Page name in check login");
        $admin = $this->session->admin;
        if($admin != array())
        {
            if($p=="login")
                redirect("home","refresh");
        }else{
            if($p!="login")
                redirect("User/index","refresh");
        }
	}
	
	
	
	

    public function userInfo($c="")
	{

        if($c=="")
            $c = "*";
        $admin = json_decode(base64_decode($this->session->admin),true);
        //var_dump($admin);
        $id = $admin['id'];
        $q = $this->db->query("SELECT $c FROM `admin` WHERE `id`='$id'");
       $sub= $q->result_array()[0];
       
        return $sub;
	}
	

    public function check_permissions($l="")
    {
    	//var_dump($l);die;
        $role = $this->userInfo('role_id')['role_id'];
        $submenu = @$this->db->query("SELECT id FROM `submenu` WHERE `is_delete`='0' AND `link`='$l'")->result_array()[0]['id'];
    //var_dump($submenu);die;
        $sub_submenu = @$this->db->query("SELECT id FROM `sub_submenu` WHERE `is_delete`='0' AND `link`='$l'")->result_array()[0]['id'];
        $permission = @$this->db->query("SELECT id FROM `permission` WHERE `role_id`='$role' AND `submenu_id`='$submenu' OR `sub_submenu_id`='$sub_submenu'");
	//var_dump($permission->num_rows());die();
        if($permission->num_rows() < 1)
        {
            redirect("home","refresh");
        }
    }

    public function checkEditDelete($l='')
    {
        $role = $this->userInfo('role_id')['role_id'];
        $submenu = $this->db->query("SELECT id FROM `submenu` WHERE `is_delete`='0' AND `link`='$l'")->result_array()[0]['id'];
        $permission = $this->db->query("SELECT * FROM `permission` WHERE `role_id`='$role' AND `submenu_id`='$submenu'")->row_array();

        if(!empty($permission))
        {
            $data=array(
                    'edit'=>false,
                    'delete'=>false
                );
            if($permission['editable']==1)
            $data['edit']=true;
            if($permission['deleteable']==1)
            $data['delete']=true;
            return $data;
        }
    }

    public function getBranch()
    {
        $role = $this->userInfo('role_id')['role_id'];
        $branch = @$this->db->query("SELECT `id` FROM `branch` WHERE `id`=2 AND `is_delete`='0'")->result_array()[0]['id'];
        
        return $branch;
    }

    public function is_super()
    {
        if($this->userInfo('role_id')['role_id']==1)
            return true;
        else
            return false;
    }

    public function limitText($t="",$l=10,$dots=true)
    {
        if($dots)
            $do = "...";
        else
            $do = "";
        if(strlen($t) > $l)
            $ret = substr($t, 0, $l) . $do;
        else
            $ret = $t;
        return $ret;
    }

    public function search_multi_arr($array=array(), $key, $val) 
    {
        foreach ($array as $item)
            if (isset($item[$key]) && $item[$key] == $val)
                return true;
        return false;
    }

    public function sendDetails($name=""){
        $user = $this->userInfo("first_name,contact_no");
        $bid = $this->getBranch();
        if($this->is_super())
            $b_name = "(Super)";
        else
            $b_name = $this->db->select("name")->from("branch")->where("id",$bid)->where("is_delete","0")->get()->row()->name;
    
        $message="Name: ".$user['first_name']." | ".$user['contact_no']." with username: ".$name." of branch: ".$b_name." has logged in to panel";
      
        
        }

}?>