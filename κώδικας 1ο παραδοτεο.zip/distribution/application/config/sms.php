<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| SMS GATEWAY API SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your sms gateway api.
|
| 
*/
$config['email'] = "shahlatifschooldaharki@gmail.com";
$config['password'] = "slmhssdaharki";
