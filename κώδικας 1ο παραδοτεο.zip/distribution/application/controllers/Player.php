<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Player extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
		$this->user_model->check_login("home");

	}
	


	public function add()
	{
	    $this->user_model->check_permissions("Player/add");
	    $branch = $this->user_model->getBranch();
		$data['menu'] = $this->load_model->menu();
          	 
		$this->load->view('header',$data);
		$this->load->view('sidebar',$data);
		$this->load->view('Player/add',$data);
    }
	



 public function save()
	{
        
        if($this->input->post())
        {
            $first_name = $this->input->post("first_name",true);
            $last_name = $this->input->post("last_name",true);
            $father_name = $this->input->post("father_name",true);
            $father_contact = $this->input->post("father_contact",true);
            $student_contact = $this->input->post("student_contact",true);
            $dob = $this->input->post("dob",true);
            if(!empty($dob))
            {
            $datee = str_replace('/', '-', $dob);
            $dob= date('Y-m-d', strtotime($datee)); 
            }
            
           $email = $this->input->post("email",true);
           $class = $this->input->post("class",true);
           $marital_status= $this->input->post("marital_status",true);
           $location = $this->input->post("location",true);
           $other_city = $this->input->post("other_city",true);
           $siblings= $this->input->post("siblings",true);
           $student_income = $this->input->post("student_income",true);
           $parent_income= $this->input->post("parent_income",true);
           $department= $this->input->post("department",true);
           
           $total_points=0;
           $siblings_points=$siblings*20;
           $incomepoints=0;
           $other_city_point=0;
           
           if(($student_income+$parent_income)==0)
           {
               $total_points="1000";
           }else{
                if(($student_income+$parent_income)<10000)
                   {
                       $incomepoints=100;
                   }
                   
                   if(($student_income+$parent_income)>=10000 && ($student_income+$parent_income)<=15000)
                   {
                       $incomepoints=30;
                   }
                   
                   if($other_city=="Yes")
                   {
                       $other_city_point=50;
                   }
                    $total_points=$incomepoints+$siblings_points+$other_city_point;
           }
          
                $data = array(
                    'first_name'=>$first_name,
                    'dob'=>$dob,
                    'last_name'=>$last_name,
                    'father_name'=>$father_name,
                    'father_contact'=>$father_contact,
                    'student_contact'=>$student_contact,
                    'email'=>$email,
                    'class'=>$class,
                    'marital_status'=>$marital_status,
                    'location'=>$location,
                    'other_city'=>$other_city,
                    'siblings'=>$siblings,
                    'student_income'=>$student_income,
                    'parent_income'=>$parent_income,
                    'total_points'=>$total_points,
                    'department'=>$department,
                    'is_active'=>1
               );
            

           $res=$this->db->insert('player',$data);
           $insert_id = $this->db->insert_id();           
      if($res)
   {
     $this->session->set_flashdata('suc_msg','Student Successfuly Register...');
   }else{
      $this->session->set_flashdata('err_msg','Student Not Register...');
   }

            redirect("Player/add","refresh");
        }
	}

    
 public function update()
    {
            $id=$this->input->post('id');
            $first_name = $this->input->post("first_name",true);
            $last_name = $this->input->post("last_name",true);
            $father_name = $this->input->post("father_name",true);
            $father_contact = $this->input->post("father_contact",true);
            $student_contact = $this->input->post("student_contact",true);
            $dob = $this->input->post("dob",true);
            if(!empty($dob))
            {
            $datee = str_replace('/', '-', $dob);
            $dob= date('Y-m-d', strtotime($datee)); 
            }
            
           $email = $this->input->post("email",true);
           $class = $this->input->post("class",true);
           $marital_status= $this->input->post("marital_status",true);
           $location = $this->input->post("location",true);
           $other_city = $this->input->post("other_city",true);
           $siblings= $this->input->post("siblings",true);
           $student_income = $this->input->post("student_income",true);
           $parent_income= $this->input->post("parent_income",true);
           $department= $this->input->post("department",true);
           
           $total_points=0;
           $siblings_points=$siblings*20;
           $incomepoints=0;
           $other_city_point=0;
           
           if(($student_income+$parent_income)==0)
           {
               $total_points=1000;
           }else{
                if(($student_income+$parent_income)<10000)
                   {
                       $incomepoints=100;
                   }
                   
                   if(($student_income+$parent_income)>=10000 && ($student_income+$parent_income)<=15000)
                   {
                       $incomepoints=30;
                   }
                   
                   if($other_city=="Yes")
                   {
                       $other_city_point=50;
                   }
                    $total_points=$incomepoints+$siblings_points+$other_city_point;
           }
                $data = array(
              
                'first_name'=>$first_name,
                'dob'=>$dob,
                'last_name'=>$last_name,
                'father_name'=>$father_name,
                'father_contact'=>$father_contact,
                'student_contact'=>$student_contact,
                'email'=>$email,
                'class'=>$class,
                'marital_status'=>$marital_status,
                'location'=>$location,
                'other_city'=>$other_city,
                'siblings'=>$siblings,
                'student_income'=>$student_income,
                'parent_income'=>$parent_income,
                'department'=>$department,
                'total_points'=>$total_points
               );
       $this->db->where('id',$id)
               ->update('player',$data);
       redirect('Player/view');
    }

public function apply_algo(){
    $data['menu'] = $this->load_model->menu();
    
    $data['departments']=$this->db->select('department')
                          ->from('player')
                          ->where('is_active',0)
                          ->where('is_delete',0)
                          ->group_by('department')
                          ->get()->result_array();
   
    $this->load->view('header',$data);
	$this->load->view('sidebar',$data);
	$this->load->view('Player/algo',$data);
}


public function search_user()
{
  $nam=$_POST['ded'];
  $serch_name=$this->db->select('*')
                       ->from('admin')
                       ->where('username',$nam)
                       ->where('is_delete',0)
                       ->get()->row_array();
                       
       if(!empty($serch_name))
        {
              echo "01";
         }else
          {
           echo "00";
            }
}


    public function view()
	{
	    $this->user_model->check_permissions("Player/view");
        $branch = $this->user_model->getBranch();
		$data['menu'] = $this->load_model->menu();
	  	
         $data['com']=$this->db->select('player.*,department.name as department')
                                ->from('player')
                                ->join('department','department.id=player.department')
                                ->where('player.is_delete',0)
                                ->get()->result_array();
		$this->load->view('header',$data);
		$this->load->view('sidebar',$data);
		$this->load->view('Player/view',$data);
	}

  public function eye($id)
  {
     
      $branch = $this->user_model->getBranch();
		$data['menu'] = $this->load_model->menu();
	  	
         $data['com']=$this->db->select('*')
                                ->from('player')
                                ->where('is_delete',0)
                                ->where('id',$id)
                                ->get()->row_array();
    
        $this->load->view('header',$data);
		$this->load->view('sidebar',$data); 
		$this->load->view('Player/eye',$data);
  }
    public function delete($id)
    {
      $data=array(
          'is_delete'=>1
      );
      $this->db->where('id',$id)
               ->update('player',$data);
               redirect('Player/view');
    }
    
   
   public function deactive($id)
    {
      $data=array(
          'is_active'=>1
      );
      $this->db->where('id',$id)
               ->update('player',$data);
               redirect('Player/view');
    }
    
     public function active($id)
    {
      $data=array(
          'is_active'=>0
      );
      $this->db->where('id',$id)
               ->update('player',$data);
               redirect('Player/view');
    }
    
    

      public function edit($id)
    {
            $branch = $this->user_model->getBranch();
	    	$data['menu'] = $this->load_model->menu();
            $this->db->select("*"); 
            $this->db->from('player');
            $this->db->where("id",$id);
            $query = $this->db->get();
            $data['com'] = $query->result_array()[0];

        $this->load->view('header',$data);
		$this->load->view('sidebar',$data);
		$this->load->view('Player/edit',$data);
    }

public function search()
{
    $branch = $this->user_model->getBranch();
		$data['menu'] = $this->load_model->menu();
          	 
		$this->load->view('header',$data);
		$this->load->view('sidebar',$data);
		$this->load->view('Player/search',$data);
}
     
 private function do_upload()
    {
        $type = explode('.', $_FILES["img"]["name"]);
        $type = $type[count($type)-1];
        $url = "./images/".uniqid(rand()).'.'.$type;
        if (in_array($type, array("png","jpg","jpeg","gif")))
            if(move_uploaded_file($_FILES["img"]["tmp_name"], $url))
                return $url;
        return ""; 
    }
}
