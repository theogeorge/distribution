<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends CI_Controller {
    public function Forget()
    {
        $this->load->view('user/Forget');
    }
    public function reset()
    {
        $email=$this->input->post('email');
        $username=$this->input->post('username');
        $pass=$this->input->post('password');
        $check=$this->db->select('*')
                        ->from('admin')
                        ->where('username',$username)
                        ->where('email',$email)
                        ->where('is_delete',0)
                        ->get()->result();
        if(empty($check))
        {
            $this->session->set_flashdata('err_msg','Record Not Found');
        }else
        {
            $passd = md5($pass);
            $data=array(
               'password'=>$passd
                );
          $this->db->where('username',$username) 
                   ->update('admin',$data);
        $this->session->set_flashdata('suc_msg','Password Reset...');  
        redirect('User/index');
        }
    }
}
?>