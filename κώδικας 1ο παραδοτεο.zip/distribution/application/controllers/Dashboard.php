<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	

    public function __construct()
    {
        parent::__construct();
        	$this->load->library("hajanasms");
		$this->user_model->check_login("home");
		$this->load->model("voucher_model");
		$this->userInfo = $this->user_model->userInfo("first_name,last_name");
		$this->load->helper('url');
    }

	public function dashboard1()
	{
	 $this->user_model->check_permissions("autopaper/chapter");
         $data['is_super'] = $this->user_model->is_super();
         $data['menu'] = $this->load_model->menu();
         $branch=$this->user_model->getbranch();
            
         $data['base_url'] = base_url();
         $data['userInfo'] = $this->userInfo;
     
        $this->load->view('header',$data);
         $this->load->view('sidebar',$data);
	$this->load->view('dash/dashboard');	
		
	}
	
	
	public function dashboard2()
	{
	 $this->user_model->check_permissions("autopaper/chapter");
         $data['is_super'] = $this->user_model->is_super();
         $data['menu'] = $this->load_model->menu();
         $branch=$this->user_model->getbranch();
            
         $data['base_url'] = base_url();
         $data['userInfo'] = $this->userInfo;
     
        $this->load->view('header',$data);
         $this->load->view('sidebar',$data);
	$this->load->view('dash/dashboard2');	
		
	}
	
	public function dashboard3()
	{
	 $this->user_model->check_permissions("autopaper/chapter");
         $data['is_super'] = $this->user_model->is_super();
         $data['menu'] = $this->load_model->menu();
         $branch=$this->user_model->getbranch();
            
         $data['base_url'] = base_url();
         $data['userInfo'] = $this->userInfo;
     
        $this->load->view('header',$data);
         $this->load->view('sidebar',$data);
	$this->load->view('dash/dashboard3');	
		
	}
	

//====================================================================================================================	

}