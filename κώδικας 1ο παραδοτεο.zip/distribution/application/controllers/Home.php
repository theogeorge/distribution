<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


    public function __construct()
    {
        parent::__construct();
		$this->user_model->check_login("home");
		$this->load->model("user_model");
    }

	public function index()
	{
	   $branch = $this->user_model->getBranch();
	   $data['menu'] = $this->load_model->menu();	

        $this->load->view('header',$data);
		$this->load->view('sidebar',$data);
		$this->load->view('home/dashboard',$data);
 
    }
}
