<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        

		$this->load->model("user_model");
		$this->load->model("generic_model");
    }

	public function login()
	{
	    
		$this->user_model->check_login("login");

        if($this->input->post())
		{
			$username = $this->input->post('username',true);
			$password = $this->input->post('password',true);
			$res=$this->user_model->login($username,$password);
			if($res=="01")
			{
              $this->session->set_flashdata('err_msg','Invalid Username or Password...');
			  redirect('User/index');
			}else{
				redirect("home","refresh");
			}
		}
	}

	public function index()
	{
	 	$this->user_model->check_login("login");
        $data['base_url'] = base_url();
		$this->load->view('user/login',$data);
	}

	public function logout()
	{
        $this->user_model->logout();
	}

	public function sabeeh()
	{
        $abc = fopen("abc.txt","w+");
fwrite($abc,"testing");
fclose($abc);
	}
	public function profile()
	{
		$data['menu'] = $this->load_model->menu();
		 

		  $this->db->select("*"); 
            $this->db->from('admin');
            $this->db->where("id",1);
            $query = $this->db->get();
            $data['com'] = $query->result_array()[0];


		$this->load->view('header',$data);
		$this->load->view('sidebar',$data);
		$this->load->view('user/edit_profile',$data);
	}

	public function update_profile()
	{
			
		    $name = $this->input->post("name",true);
            $u_name = $this->input->post("u_name",true);
            $pass = $this->input->post("pass",true);
            $contact_sec = $this->input->post("contact_sec",true);
            $email = $this->input->post("email",true);
         $data = array(

                'first_name'=>$name,
                'username'=>$u_name,
                'password'=>md5($pass),
                'contact_no'=>$contact_sec,
                'email'=>$email
                
              );
              $this->db->where('id',1)
                             ->update('admin',$data);
     
			redirect('home/index');
	}

}
